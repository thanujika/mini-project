/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

 

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException; 

/**
 *
 * @author thanu
 */
public class LoginController {
     public static boolean Login(String username, String password) throws SQLException, ClassNotFoundException {

        String SQL = "SELECT * FROM users WHERE username=? AND password=?";

         
        PreparedStatement stm = conn.prepareStatement(SQL);
        stm.setObject(1, username);  
        stm.setObject(2, password);
        ResultSet rst = stm.executeQuery();

        if (rst.next()) {


        if(!rst.getString(1).equals(username)){ 
            return false;
        }
        String pwd = rst.getString(2);
        if (pwd.equals(password)) {
            return true;
        }
    }
        return false;

}

    private static class conn {

        private static PreparedStatement prepareStatement(String SQL) {
            throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        }

        public conn() {
        }
    }
    
}
 